CREATE PROCEDURE procStorreAn20
AS
    SELECT *
    FROM ProdLev
    WHERE Antal>20
GO
