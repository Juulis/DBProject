CREATE PROCEDURE procAntalIn
@antal int
AS
    SELECT *
    FROM ProdLev
    WHERE @antal > antal
RETURN
GO
