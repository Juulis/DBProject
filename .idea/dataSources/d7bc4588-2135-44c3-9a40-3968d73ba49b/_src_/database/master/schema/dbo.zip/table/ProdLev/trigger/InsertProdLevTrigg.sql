CREATE TRIGGER InsertProdLevTrigg
ON ProdLev 
FOR INSERT AS 
IF (SELECT COUNT(*)
    FROM inserted i, Produkt p
    WHERE i.pid = p.pid)<>
    (SELECT COUNT(*)
    FROM inserted)

BEGIN
    PRINT 'Produkten saknas'
    ROLLBACK TRAN
    RETURN
END

IF (SELECT COUNT(*)
    FROM inserted i, Leverantor l
    WHERE i.LevId = l.levid)<>
    (SELECT COUNT(*)
    FROM inserted)
BEGIN
    PRINT 'Leverantören saknas'
    ROLLBACK TRAN
    RETURN
END
GO
